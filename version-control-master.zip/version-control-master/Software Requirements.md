#### Download/Install required software 
This needs to be an entirely separate document
- Git
- Homebrew
  ```shell
  brew install git
  ```
  ```shell
  brew install gh
  ```
- Visual Studio Code