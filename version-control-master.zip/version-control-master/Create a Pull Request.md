## Create Pull Request
In browser, select Compare & Pull Request
Add verbiage about the commit you made
Select Create Pull Request
Once a pull request has been made, the code needs to be reviewed by the Repository’s Code Owner to be merged into master branch. 
  - In this case, you are the owner, but normally the Lead Engineer(s) on the project will review the code then perform the merge if they determine the code is correct. 